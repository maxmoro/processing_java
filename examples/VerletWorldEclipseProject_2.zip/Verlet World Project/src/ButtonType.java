enum ButtonType{
  RECT,
  ROUNDED_RECT
};