enum Layout {
  LEFT, RIGHT, TOP, BOTTOM
};

